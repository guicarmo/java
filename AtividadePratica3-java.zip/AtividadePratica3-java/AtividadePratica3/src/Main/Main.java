package Main;
import Sistema.Sistema;

public class Main {
    public static void main(String[] args) {
        Sistema.executar();
    }    
}
