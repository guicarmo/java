package ClasseAbstrata;

public interface Trabalhavel {
    
    public String trabalhar();

    public String relatarProgresso();
}
